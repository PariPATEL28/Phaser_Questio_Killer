function preload(params){
    this.load.spritesheet("activePnj","./assets/Sprites/spritePhysics.png", 
        {frameWidth:160, frameHeight:160});
    // this.load.spritesheet("ground","./assets/Sprites/spritePhysics.png", 
    //     {frameWidth:160, frameHeight:160});

    this.load.image("plateform","./assets/Sprites/Label.png");
    this.load.image("plateform","./assets/Sprites/Label.png");
}

let cursors;
let player;

function create(params){
    player = this.physics.add.sprite(100,100, 'activePnj');
    player.setVelocityX(150);
    player.setCollideWorldBounds(true);
    player.setBounce(0.2);
    player.setScale(0.6);

    let ground =  this.physics.add.staticGroup();
    ground.create(200, 300,"plateform");
    ground.create(500, 600,"plateform");
    //ground.create(200, 710,"ground");


    function callbackCollider(){
        console.log("ouch");
    }
    let maincollider = this.physics.add.collider(player, ground, callbackCollider);
 
    cursors = this.input.keyboard.createCursorKeys();
}

function update(params){
    if(player.body.touching.down){
        console.log('contact');
    }
    if(cursors.right.isDown){//cursors.right.isDown && player.body.touching.down -player down then canot move right
        player.setVelocityX(200);
        player.setFlipX(false);  //for player front back position
        console.log("right");
    } 
    else if(cursors.left.isDown){//&& player.body.touching.down -when you add player can not move left touching down plate form
        player.setVelocityX(-200);
        player.setFlipX(true);
        console.log("left");
    }
    else if(cursors.up.isDown && player.body.touching.down){
        player.setVelocityY(-200);
        console.log("Up");
        
    }    
    else{
        player.setVelocityX(0);
    }
}

export let plateformScene = {
    key: "plateform",
    preload: preload,
    create: create,
    update: update,
}
